#include<stdio.h>

void main()
{
	int a, b;
	a = 0;
	b = 0;

	printf("\n %d \n %d",a,b);
}
